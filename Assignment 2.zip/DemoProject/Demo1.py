from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from mail import mailCheck
import time

class Democlass():
    def demotest1(self):
        driverpath = input("Enter the full path to chrome driver using double back-slashes: ")
        driver = webdriver.Chrome(driverpath)
        driver.implicitly_wait(10)
        driver.get("http://jt-dev.azurewebsites.net/#/SignUp")
        driver.maximize_window()

        # Language dropdown caret element click
        dropdown_caret = driver.find_element_by_xpath("//div[@id='language']/div[1]/span//i[@class='caret pull-right']")
        dropdown_caret.click()

        # Check for English Language
        try:
            english = driver.find_element_by_xpath("//div[@id='language']/ul/li//div[@id='ui-select-choices-row-1-0']/a/div")
            if english.is_displayed():
                print("English is present.")
            else:
                print("English is not present.")
        except NoSuchElementException:
            print("English element is not present and the test failed.")

        # Check for Dutch Language
        try:
            dutch = driver.find_element_by_xpath(
                "//div[@id='language']/ul/li//div[@id='ui-select-choices-row-1-1']/a/div")
            if dutch.is_displayed():
                print("Dutch is present.")
            else:
                print("Dutch is not present.")
        except NoSuchElementException:
            print("Dutch element is not present and the test failed.")

        # Full Name send keys
        try:
            full_name = driver.find_element_by_id("name")
            full_name.send_keys("Amrutanshu Nege")
        except NoSuchElementException:
            raise Exception("Name field is not present or not enabled.\n Test case failed")

        # Organization name
        try:
            org_name = driver.find_element_by_id("orgName")
            org_name.send_keys("Amrutanshu Nege")
        except NoSuchElementException:
            raise Exception("Organization field is not present or not enabled. \n Test case failed")

        # Email ID
        try:
            email_id = driver.find_element_by_id("singUpEmail")
            email_id.send_keys("amrutanshu2010@gmail.com")
        except NoSuchElementException:
            raise Exception("Email ID field is not present or not enabled. \n Test case failed")

        # Click on terms and condition
        try:
            terms = driver.find_element_by_css_selector("label.ui-checkbox span.black-color")

            # checking if element is already checked or not
            try:
                check = driver.find_element_by_xpath(
                    "//label[@class='ui-checkbox']/input[@class='ng-untouched ng-valid ng-not-empty ng-dirty ng-valid-parse']")
                if check is not None:
                    print("The terms and conditions checkbox is already checked.")
            except:
                print("The terms and conditions checkbox is not checked, lets check it now.")
                terms.click()
                time.sleep(5)
        except NoSuchElementException:
            raise Exception("Terms and condition checkbox is not present or not enabled. \n The test case failed.")

        # Click on submit
        try:
            submit = driver.find_element_by_xpath("//button[@type='submit']")
            submit.click()
            time.sleep(15)
        except NoSuchElementException:
            raise Exception("Submit button is not present.")

        # Mail sent confirmation
        try:
            confirmation = driver.find_element_by_xpath("//form[@name='signUpForm']//span[@class='ng-binding']")
            if confirmation.is_displayed():
                print("Email sent from the website")
            else:
                print("Email not sent")
        except NoSuchElementException:
            raise Exception("Confirmation element is not present.")

        # Mail received confirmation
        mail_user = input("gmail username: ")
        mc = mailCheck.MailCheck()
        mc.mail(mail_user)

cc = Democlass()
cc.demotest1()
