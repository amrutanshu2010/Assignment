import imaplib
import email
import getpass
import time

class MailCheck():

    def mail(self, username):

        # Gaining access to mailbox
        self.username = username
        password = getpass.getpass("Enter Password: ")
        mail = imaplib.IMAP4_SSL("imap.gmail.com")
        mail.login(username, password)

        # Specifying the mailbox to get the data from

        mail.select("INBOX")
        result, number = mail.search(None, '(FROM "donotreply-dev@jabatalks.com")')
        uid = number[0].split()
        uid = [id.decode("utf-8") for id in uid]
        result, message = mail.fetch(','.join(uid), '(RFC822)')

        body_list = []
        date_list = []
        from_list = []
        subject_list = []
        for _, mes in message[::2]:
            email_message = email.message_from_bytes(mes)
            email_subject = email.header.decode_header(email_message['Subject'])[0]

            for part in email_message.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True)
                    body = body.decode("utf-8")
                    body_list.append(body)
                else:
                    continue

                if isinstance(email_subject[0], bytes):
                    decoded = email_subject.decode(errors="ignore")
                    subject_list.append(decoded)
                else:
                    subject_list.append(email_subject[0])

            date_list.append(email_message.get('date'))
            fromlist = email_message.get('From')
            fromlist = fromlist.split("<")[0].replace('"', '')
            from_list.append(fromlist)

        check_subject = "Hi Amrutanshu Nege - Please Complete JabaTalks Account"

        if check_subject == subject_list[-1]:
            print("Email received")
            time.sleep(30)
        else:
            print("Email not received")
            time.sleep(30)



